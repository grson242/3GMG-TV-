package tv.gmg

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

object M3u {
    private val groupRx = Regex("group-title=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""; var group = ""
        for (raw in text.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXTINF") -> {
                    name = l.substringAfterLast(",").trim()
                    group = groupRx.find(l)?.groupValues?.get(1) ?: ""
                }
                l.isNotEmpty() && !l.startsWith("#") && name.isNotEmpty() -> {
                    out += Channel(id = l, name = name, logo = "", catId = group, url = l)
                    name = ""
                }
            }
        }
        return out
    }

    /** Charge la playlist embarquée ; les liens qui sont eux-mêmes des playlists (.m3u) sont développés. */
    suspend fun loadFree(ctx: Context): List<Channel> = withContext(Dispatchers.IO) {
        val base = parse(ctx.assets.open("gratuit.m3u").bufferedReader().readText())
        base.flatMap { c ->
            if (c.url.endsWith(".m3u", true)) {
                runCatching {
                    parse(URL(c.url).readText()).map { it.copy(catId = c.catId) }
                }.getOrDefault(emptyList())
            } else listOf(c)
        }
    }

    fun categories(list: List<Channel>) =
        list.map { it.catId }.filter { it.isNotEmpty() }.distinct().map { Category(it, it) }
}
