# 3GMG TV – Application Android

Application Android de 3GMG TV : connexion à l'abonnement IPTV (API Xtream), chaînes en direct par catégorie, films, programme en cours (EPG) et lecteur intégré.

## Build
Le workflow GitHub Actions (`.github/workflows/build-apk.yml`) compile l'APK automatiquement à chaque push. Télécharge-le dans Actions > dernière exécution > Artifacts > `3GMG-TV-apk`.
