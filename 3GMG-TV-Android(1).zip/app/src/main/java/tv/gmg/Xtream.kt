package tv.gmg

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Channel(
    val id: String, val name: String, val logo: String,
    val catId: String = "", val vod: Boolean = false, val ext: String = "m3u8"
)
data class Category(val id: String, val name: String)
data class Account(val server: String, val user: String, val pass: String, val expiry: Long)

object Xtream {
    private suspend fun get(url: String): String =
        withContext(Dispatchers.IO) { URL(url).readText() }

    private fun api(a: Account, action: String, extra: String = "") =
        "${a.server}/player_api.php?username=${a.user}&password=${a.pass}&action=$action$extra"

    suspend fun login(server: String, user: String, pass: String): Account {
        val s = server.trimEnd('/')
        val j = JSONObject(get("$s/player_api.php?username=$user&password=$pass"))
        val info = j.getJSONObject("user_info")
        if (info.optInt("auth") != 1) error("Identifiants invalides")
        return Account(s, user, pass, info.optString("exp_date", "0").toLongOrNull() ?: 0L)
    }

    suspend fun categories(a: Account, vod: Boolean = false): List<Category> {
        val action = if (vod) "get_vod_categories" else "get_live_categories"
        val arr = JSONArray(get(api(a, action)))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Category(o.getString("category_id"), o.getString("category_name"))
        }
    }

    suspend fun channels(a: Account): List<Channel> {
        val arr = JSONArray(get(api(a, "get_live_streams")))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Channel(o.getString("stream_id"), o.getString("name"),
                o.optString("stream_icon"), o.optString("category_id"))
        }
    }

    suspend fun movies(a: Account): List<Channel> {
        val arr = JSONArray(get(api(a, "get_vod_streams")))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Channel(o.getString("stream_id"), o.getString("name"),
                o.optString("stream_icon"), o.optString("category_id"),
                vod = true, ext = o.optString("container_extension", "mp4"))
        }
    }

    /** Programme en cours et suivant (EPG) */
    suspend fun epg(a: Account, c: Channel): List<String> = runCatching {
        val j = JSONObject(get(api(a, "get_short_epg", "&stream_id=${c.id}&limit=2")))
        val l = j.getJSONArray("epg_listings")
        (0 until l.length()).map {
            String(Base64.decode(l.getJSONObject(it).getString("title"), Base64.DEFAULT))
        }
    }.getOrDefault(emptyList())

    fun streamUrl(a: Account, c: Channel) =
        if (c.vod) "${a.server}/movie/${a.user}/${a.pass}/${c.id}.${c.ext}"
        else "${a.server}/live/${a.user}/${a.pass}/${c.id}.m3u8"
}
