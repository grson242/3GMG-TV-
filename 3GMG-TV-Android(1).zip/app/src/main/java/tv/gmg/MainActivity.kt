package tv.gmg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

val Violet = Color(0xFF8A2BE2)
val Rose = Color(0xFFFF2D95)
val Fond = Color(0xFF12001F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Rose, background = Fond, surface = Fond)) {
                Surface(Modifier.fillMaxSize(), color = Fond) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var account by remember { mutableStateOf<Account?>(null) }
    val a = account
    if (a == null) LoginScreen { account = it } else Home(a) { account = null }
}

@Composable
fun LoginScreen(onOk: (Account) -> Unit) {
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("3GMG TV", style = MaterialTheme.typography.headlineLarge, color = Rose)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(server, { server = it }, label = { Text("Serveur (http://...)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (err.isNotEmpty()) Text(err, color = Color.Red)
        Spacer(Modifier.height(16.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            busy = true; err = ""
            scope.launch {
                try { onOk(Xtream.login(server.trim(), user.trim(), pass)) }
                catch (e: Exception) { err = "Connexion impossible : ${e.message}" }
                busy = false
            }
        }) { Text(if (busy) "Connexion..." else "Se connecter") }
    }
}

@Composable
fun Home(a: Account, onLogout: () -> Unit) {
    var vodMode by remember { mutableStateOf(false) }
    var items by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var cats by remember { mutableStateOf<List<Category>>(emptyList()) }
    var cat by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<Channel?>(null) }
    var epg by remember { mutableStateOf<List<String>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }

    // Rechargement auto : au changement d'onglet, au clic sur Actualiser et toutes les 30 min
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30 * 60 * 1000L); tick++ } }
    LaunchedEffect(a, vodMode, tick) {
        runCatching {
            cats = Xtream.categories(a, vodMode)
            items = if (vodMode) Xtream.movies(a) else Xtream.channels(a)
        }
    }
    LaunchedEffect(current) {
        val c = current
        epg = if (c != null && !c.vod) Xtream.epg(a, c) else emptyList()
    }

    val exp = if (a.expiry > 0) SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(a.expiry * 1000)) else "illimité"
    Column(Modifier.fillMaxSize()) {
        current?.let {
            Player(Xtream.streamUrl(a, it))
            if (epg.isNotEmpty()) Text("En cours : " + epg.joinToString("  ›  "),
                Modifier.padding(8.dp), color = Rose)
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Expire : $exp", color = Rose)
            Text("Actualiser", Modifier.clickable { tick++ })
            Text("Déconnexion", Modifier.clickable { onLogout() })
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!vodMode, { vodMode = false; cat = null }, { Text("Chaînes") })
            FilterChip(vodMode, { vodMode = true; cat = null }, { Text("Films") })
        }
        androidx.compose.foundation.lazy.LazyRow(
            Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(cat == null, { cat = null }, { Text("Tout") }) }
            items(cats) { c -> FilterChip(cat == c.id, { cat = c.id }, { Text(c.name) }) }
        }
        OutlinedTextField(query, { query = it }, label = { Text("Rechercher") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
        LazyColumn {
            items(items.filter { (cat == null || it.catId == cat) && it.name.contains(query, true) }) { c ->
                Text(c.name, Modifier.fillMaxWidth().clickable { current = c }.padding(16.dp))
                HorizontalDivider(color = Violet)
            }
        }
    }
}

@Composable
fun Player(url: String) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    LaunchedEffect(url) { player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.playWhenReady = true }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(220.dp).background(Color.Black))
}
