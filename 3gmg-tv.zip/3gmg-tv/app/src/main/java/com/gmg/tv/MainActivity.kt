package com.gmg.tv

import android.content.Context
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Bg = Color(0xFF0B0614)
val Pink = Color(0xFFFF2BD6)
val Purple = Color(0xFF8A2BE2)

// kind: live | vod | serie (dossier) | ep (épisode)
data class Item(val id: String, val name: String, val kind: String, val ext: String = "mp4") {
    val key get() = "$kind|$id|$ext|$name"
}

fun itemFromKey(k: String): Item? = k.split("|", limit = 4).let {
    if (it.size == 4) Item(it[1], it[3], it[0], it[2]) else null
}

class Api(val base: String, val u: String, val p: String) {
    suspend fun get(action: String = "", extra: String = ""): String = withContext(Dispatchers.IO) {
        val a = if (action.isNotEmpty()) "&action=$action" else ""
        URL("$base/player_api.php?username=$u&password=$p$a$extra").readText()
    }
    fun url(i: Item) = when (i.kind) {
        "live" -> "$base/live/$u/$p/${i.id}.m3u8"
        "vod" -> "$base/movie/$u/$p/${i.id}.${i.ext}"
        else -> "$base/series/$u/$p/${i.id}.${i.ext}"
    }
}

fun parse(a: JSONArray, kind: String) = (0 until a.length()).map {
    val o = a.getJSONObject(it)
    Item(o.optString(if (kind == "serie") "series_id" else "stream_id"), o.optString("name"), kind,
        o.optString("container_extension", "mp4").ifBlank { "mp4" })
}

fun expText(e: String) =
    if (e.isBlank() || e == "null") "Illimité"
    else SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(e.toLong() * 1000))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Pink)) { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("3gmg", Context.MODE_PRIVATE) }
    var api by remember {
        mutableStateOf(prefs.getString("server", null)?.let {
            Api(it, prefs.getString("user", "")!!, prefs.getString("pass", "")!!)
        })
    }
    var expiry by remember { mutableStateOf(prefs.getString("exp", "") ?: "") }
    Box(Modifier.fillMaxSize().background(Bg)) {
        val a = api
        if (a == null) Login(prefs) { na, e -> api = na; expiry = e }
        else Home(a, expiry, prefs) {
            prefs.edit().clear().apply(); api = null
        }
    }
}

@Composable
fun Login(prefs: android.content.SharedPreferences, onOk: (Api, String) -> Unit) {
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxSize()) { Column(Modifier.align(Alignment.Center).width(480.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("3GMG TV", color = Pink, fontSize = 44.sp)
        OutlinedTextField(server, { server = it }, label = { Text("Serveur (http://...:port)") }, singleLine = true)
        OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, singleLine = true)
        OutlinedTextField(pass, { pass = it }, label = { Text("Mot de passe") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        Button(enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple), onClick = {
            busy = true; msg = ""
            val base = (if (server.startsWith("http")) server else "http://$server").trim().trimEnd('/')
            val api = Api(base, user.trim(), pass.trim())
            scope.launch {
                try {
                    val ui = JSONObject(api.get()).getJSONObject("user_info")
                    if (ui.optString("auth") != "1" || ui.optString("status") == "Disabled") msg = "Identifiants invalides"
                    else {
                        val exp = ui.optString("exp_date")
                        prefs.edit().putString("server", base).putString("user", api.u)
                            .putString("pass", api.p).putString("exp", exp).apply()
                        onOk(api, exp)
                    }
                } catch (e: Exception) { msg = "Connexion impossible" }
                busy = false
            }
        }) { Text(if (busy) "Connexion..." else "Se connecter") }
        if (msg.isNotEmpty()) Text(msg, color = Color.Red)
    } }
}

@Composable
fun Home(api: Api, expiry: String, prefs: android.content.SharedPreferences, onLogout: () -> Unit) {
    val tabs = listOf("📺 TV", "🎬 Films", "📼 Séries", "⭐ Favoris")
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<Item>>(emptyList()) }
    var episodes by remember { mutableStateOf<List<Item>?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var playing by remember { mutableStateOf<Item?>(null) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(tab) {
        episodes = null; status = "Chargement..."
        try {
            items = when (tab) {
                0 -> parse(JSONArray(api.get("get_live_streams")), "live")
                1 -> parse(JSONArray(api.get("get_vod_streams")), "vod")
                2 -> parse(JSONArray(api.get("get_series")), "serie")
                else -> emptyList()
            }
            status = ""
        } catch (e: Exception) { status = "Erreur de chargement" }
    }
    fun toggleFav(i: Item) {
        favs = if (i.key in favs) favs - i.key else favs + i.key
        prefs.edit().putStringSet("favs", favs).apply()
    }
    fun open(i: Item) {
        if (i.kind == "serie") scope.launch {
            try {
                val eps = JSONObject(api.get("get_series_info", "&series_id=${i.id}")).getJSONObject("episodes")
                val out = mutableListOf<Item>()
                eps.keys().forEach { s ->
                    val arr = eps.getJSONArray(s)
                    for (k in 0 until arr.length()) {
                        val e = arr.getJSONObject(k)
                        out += Item(e.optString("id"), "S$s E${e.optString("episode_num")} - ${e.optString("title")}",
                            "ep", e.optString("container_extension", "mp4"))
                    }
                }
                episodes = out
            } catch (e: Exception) { status = "Série indisponible" }
        } else playing = i
    }

    val base = episodes ?: if (tab == 3) favs.mapNotNull { itemFromKey(it) } else items
    val shown = base.filter { it.name.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("3GMG TV", color = Pink, fontSize = 26.sp)
            tabs.forEachIndexed { n, t ->
                Focusable(Modifier, { tab = n }, selected = n == tab) { Text(t, color = Color.White, modifier = Modifier.padding(12.dp)) }
            }
            Spacer(Modifier.weight(1f))
            Text("Expire : ${expText(expiry)}", color = Color.LightGray)
            Focusable(Modifier, onLogout) { Text("🚪 Quitter", color = Color.White, modifier = Modifier.padding(12.dp)) }
        }
        OutlinedTextField(query, { query = it }, label = { Text("🔎 Recherche") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        if (status.isNotEmpty()) Text(status, color = Color.LightGray)
        LazyColumn {
            items(shown) { i ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Focusable(Modifier.weight(1f), { open(i) }) {
                        Text(i.name, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(14.dp))
                    }
                    if (i.kind != "ep") {
                        Spacer(Modifier.width(8.dp))
                        Focusable(Modifier, { toggleFav(i) }) {
                            Text(if (i.key in favs) "⭐" else "☆", fontSize = 20.sp, color = Color.White, modifier = Modifier.padding(14.dp))
                        }
                    }
                }
            }
        }
    }
    BackHandler(enabled = episodes != null && playing == null) { episodes = null }
    playing?.let { Player(api, it) { playing = null } }
}

@Composable
fun Focusable(m: Modifier, onClick: () -> Unit, selected: Boolean = false, c: @Composable () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(m.clip(RoundedCornerShape(10.dp))
        .background(if (f) Pink else if (selected) Purple else Color(0x33FFFFFF))
        .onFocusChanged { f = it.isFocused }
        .clickable(onClick = onClick)) { c() }
}

@Composable
fun Player(api: Api, item: Item, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(api.url(item))); prepare(); playWhenReady = true } }
    var epg by remember { mutableStateOf("") }
    LaunchedEffect(item) {
        if (item.kind == "live") try {
            val l = JSONObject(api.get("get_short_epg", "&stream_id=${item.id}&limit=1")).getJSONArray("epg_listings")
            if (l.length() > 0) epg = String(Base64.decode(l.getJSONObject(0).optString("title"), Base64.DEFAULT))
        } catch (e: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler { onClose() }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.TopStart).padding(24.dp)) {
            Text(item.name, color = Color.White, fontSize = 22.sp)
            if (epg.isNotEmpty()) Text("EPG : $epg", color = Pink, fontSize = 18.sp)
        }
    }
}
