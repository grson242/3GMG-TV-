package com.gmg.tv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.MediaController

class PlayerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("stream_url").orEmpty()
        val title = intent.getStringExtra("title").orEmpty()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        val label = TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(0x88000000.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 8, 24, 8)
        }
        root.addView(label, FrameLayout.LayoutParams(-1, 58, Gravity.TOP))
        setContentView(root)
        video.setMediaController(MediaController(this))
        video.setVideoPath(url)
        video.setOnErrorListener { _, _, _ ->
            label.text = "$title — lecture impossible avec le lecteur natif. Vérifiez le flux ou utilisez un lecteur compatible."
            true
        }
        video.setOnPreparedListener { mp -> mp.start() }
        video.start()
    }
}
