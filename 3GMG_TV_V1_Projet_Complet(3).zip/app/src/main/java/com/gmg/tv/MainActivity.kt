package com.gmg.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 24)
    private val gold = Color.rgb(212, 175, 55)
    private val white = Color.WHITE
    private var api: XtreamApi? = null
    private var account: XtreamAccount? = null
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun baseRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(48, 24, 48, 24)
        setBackgroundColor(bg)
        isFocusableInTouchMode = true
    }

    private fun label(text: String, size: Float = 18f, color: Int = white) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
        }

    private fun edit(hintText: String, secret: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            textSize = 18f
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            inputType = if (secret) 129 else if (hintText.startsWith("Serveur"))  URI_INPUT else EditorInfo.TYPE_CLASS_TEXT
            setPadding(16, 4, 16, 4)
            setBackgroundColor(Color.rgb(37, 42, 50))
        }

    private fun addRow(parent: LinearLayout, view: View, height: Int = 58) {
        parent.addView(view, LinearLayout.LayoutParams(-1, height).apply {
            setMargins(0, 6, 0, 6)
        })
    }

    private fun showLogin() {
        root = baseRoot()
        addRow(root, label("3GMG TV", 38f, gold), 70)
        addRow(root, label("Connectez-vous à votre abonnement", 18f), 42)
        val host = edit("Serveur (ex. http://serveur:port)")
        val user = edit("Nom d'utilisateur")
        val pass = edit("Mot de passe", true)
        addRow(root, host); addRow(root, user); addRow(root, pass)
        val button = Button(this).apply { text = "SE CONNECTER"; isFocusable = true }
        addRow(root, button, 64)
        val status = label("Entrez les identifiants fournis par 3GMG TV.", 15f, Color.LTGRAY)
        addRow(root, status, 48)
        button.setOnClickListener {
            val server = host.text.toString().trim()
            val username = user.text.toString().trim()
            val password = pass.text.toString()
            if (server.isBlank() || username.isBlank() || password.isBlank()) {
                status.text = "Veuillez remplir les trois champs."
                return@setOnClickListener
            }
            button.isEnabled = false
            status.text = "Connexion au serveur..."
            thread {
                try {
                    val client = XtreamApi(server, username, password)
                    val acc = client.authenticate()
                    api = client
                    account = acc
                    runOnUiThread { showHome() }
                } catch (e: Exception) {
                    runOnUiThread {
                        status.text = e.message ?: "Connexion impossible."
                        button.isEnabled = true
                    }
                }
            }
        }
        setContentView(root)
        button.requestFocus()
    }

    private fun showHome() {
        val acc = account ?: return showLogin()
        root = baseRoot()
        addRow(root, label("3GMG TV", 36f, gold), 64)
        addRow(root, label("Compte : ${acc.username}   •   Statut : ${acc.status}   •   Expiration : ${formatExpiry(acc.expiryDate)}", 16f), 48)
        val intro = label("Choisissez une rubrique", 20f)
        addRow(root, intro, 44)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun navButton(text: String, type: String) = Button(this).apply {
            this.text = text
            isFocusable = true
            setOnClickListener { loadCategories(type) }
        }
        listOf(
            navButton("TV EN DIRECT", "live"),
            navButton("FILMS", "movie"),
            navButton("SÉRIES", "series")
        ).forEach { row.addView(it, LinearLayout.LayoutParams(0, 72, 1f).apply { setMargins(8, 8, 8, 8) }) }
        root.addView(row, LinearLayout.LayoutParams(-1, 90))
        val status = label("Les rubriques disponibles dépendent de ton serveur.", 15f, Color.LTGRAY)
        addRow(root, status, 44)
        val logout = Button(this).apply { text = "DÉCONNEXION"; setOnClickListener { api = null; account = null; showLogin() } }
        addRow(root, logout, 60)
        setContentView(root)
        row.getChildAt(0).requestFocus()
    }

    private fun loadCategories(type: String) {
        val client = api ?: return showLogin()
        showLoading("Chargement des catégories...")
        thread {
            try {
                val cats = when (type) {
                    "live" -> client.liveCategories()
                    "movie" -> client.vodCategories()
                    else -> client.seriesCategories()
                }
                runOnUiThread { showCategoryList(type, cats) }
            } catch (e: Exception) {
                runOnUiThread { showMessage("Impossible de charger les catégories : ${e.message}") }
            }
        }
    }

    private fun showCategoryList(type: String, cats: List<XtreamCategory>) {
        root = baseRoot()
        addRow(root, label(titleFor(type), 30f, gold), 60)
        val back = Button(this).apply { text = "← RETOUR"; setOnClickListener { showHome() } }
        addRow(root, back, 54)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (cats.isEmpty()) {
            list.addView(label("Aucune catégorie retournée par le serveur.", 17f))
        } else {
            cats.forEach { cat ->
                val b = Button(this).apply {
                    text = cat.name
                    isFocusable = true
                    setOnClickListener { loadItems(type, cat) }
                }
                list.addView(b, LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 3, 0, 3) })
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (cats.isNotEmpty()) list.getChildAt(0).requestFocus() else back.requestFocus()
    }

    private fun loadItems(type: String, cat: XtreamCategory) {
        val client = api ?: return showLogin()
        showLoading("Chargement de ${cat.name}...")
        thread {
            try {
                val items = when (type) {
                    "live" -> client.liveStreams(cat.id)
                    "movie" -> client.vodStreams(cat.id)
                    else -> client.series(cat.id)
                }
                runOnUiThread { showItems(type, cat.name, items) }
            } catch (e: Exception) {
                runOnUiThread { showMessage("Impossible de charger les contenus : ${e.message}") }
            }
        }
    }

    private fun showItems(type: String, categoryName: String, items: List<XtreamItem>) {
        root = baseRoot()
        addRow(root, label(categoryName, 28f, gold), 58)
        val back = Button(this).apply { text = "← CATÉGORIES"; setOnClickListener { loadCategories(type) } }
        addRow(root, back, 50)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) list.addView(label("Aucun contenu dans cette catégorie.", 17f))
        items.forEach { item ->
            val b = Button(this).apply {
                text = item.name
                isFocusable = true
                setOnClickListener {
                    if (item.streamType == "series") {
                        showMessage("Séries : la liste des épisodes sera ajoutée dans une prochaine version. Cette V1 affiche les séries disponibles.")
                    } else {
                        val client = api ?: return@setOnClickListener
                        val intent = Intent(this@MainActivity, PlayerActivity::class.java)
                        intent.putExtra("stream_url", client.streamUrl(item))
                        intent.putExtra("title", item.name)
                        startActivity(intent)
                    }
                }
            }
            list.addView(b, LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 3, 0, 3) })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (items.isNotEmpty()) list.getChildAt(0).requestFocus() else back.requestFocus()
    }

    private fun showLoading(message: String) {
        root = baseRoot()
        addRow(root, label("3GMG TV", 34f, gold), 60)
        addRow(root, label(message, 19f), 60)
        setContentView(root)
    }

    private fun showMessage(message: String) {
        root = baseRoot()
        addRow(root, label("3GMG TV", 34f, gold), 60)
        addRow(root, label(message, 18f), 100)
        val back = Button(this).apply { text = "RETOUR"; setOnClickListener { showHome() } }
        addRow(root, back)
        setContentView(root)
        back.requestFocus()
    }

    private fun titleFor(type: String) = when (type) {
        "live" -> "TV EN DIRECT"
        "movie" -> "FILMS"
        else -> "SÉRIES"
    }

    private fun formatExpiry(raw: String): String {
        if (raw.isBlank() || raw == "null" || raw == "0") return "non fournie"
        return try {
            val ts = raw.toLong()
            if (ts > 1000000000L) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(ts * 1000))
            else raw
        } catch (_: Exception) { raw }
    }

    companion object { private const val URI_INPUT = 17 }
}
