package com.gmg.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class XtreamApi(
    private val serverInput: String,
    private val username: String,
    private val password: String
) {
    private val server = serverInput.trim().trimEnd('/')

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun endpoint(action: String? = null): String {
        val base = "$server/player_api.php?username=${enc(username)}&password=${enc(password)}"
        return if (action.isNullOrBlank()) base else "$base&action=${enc(action)}"
    }

    private fun getJson(url: String): Any {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 18000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "3GMG-TV/1.0")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw Exception("Erreur serveur HTTP $code")
            return when (body.trim().firstOrNull()) {
                '[' -> JSONArray(body)
                '{' -> JSONObject(body)
                else -> throw Exception("Réponse serveur non reconnue")
            }
        } finally {
            conn.disconnect()
        }
    }

    fun authenticate(): XtreamAccount {
        val json = getJson(endpoint()) as? JSONObject
            ?: throw Exception("Réponse d'authentification invalide")
        val info = json.optJSONObject("user_info")
            ?: throw Exception("API incompatible : user_info absent")
        if (info.optString("auth", "0") != "1") {
            throw Exception("Identifiants refusés ou abonnement inactif")
        }
        return XtreamAccount(
            server = server,
            username = username,
            password = password,
            expiryDate = info.optString("exp_date", ""),
            status = info.optString("status", "Active")
        )
    }

    fun liveCategories(): List<XtreamCategory> = categories("get_live_categories")
    fun vodCategories(): List<XtreamCategory> = categories("get_vod_categories")
    fun seriesCategories(): List<XtreamCategory> = categories("get_series_categories")

    private fun categories(action: String): List<XtreamCategory> {
        val arr = getJson(endpoint(action)) as? JSONArray
            ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            XtreamCategory(o.optString("category_id"), o.optString("category_name", "Sans catégorie"))
        }
    }

    fun liveStreams(categoryId: String? = null): List<XtreamItem> =
        streams("get_live_streams", categoryId, "live")

    fun vodStreams(categoryId: String? = null): List<XtreamItem> =
        streams("get_vod_streams", categoryId, "movie")

    fun series(categoryId: String? = null): List<XtreamItem> =
        streams("get_series", categoryId, "series")

    private fun streams(action: String, categoryId: String?, type: String): List<XtreamItem> {
        val suffix = if (categoryId.isNullOrBlank()) "" else "&category_id=${enc(categoryId)}"
        val arr = getJson(endpoint(action) + suffix) as? JSONArray
            ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            XtreamItem(
                id = o.optString(if (type == "series") "series_id" else "stream_id"),
                name = o.optString("name", "Sans titre"),
                streamType = type,
                categoryId = o.optString("category_id"),
                icon = o.optString(if (type == "series") "cover" else "stream_icon"),
                containerExtension = o.optString("container_extension", "mp4")
            )
        }
    }

    fun streamUrl(item: XtreamItem): String {
        val id = enc(item.id)
        return when (item.streamType) {
            "live" -> "$server/live/${enc(username)}/${enc(password)}/$id.ts"
            "movie" -> "$server/movie/${enc(username)}/${enc(password)}/$id.${item.containerExtension.ifBlank { "mp4" }}"
            else -> "$server/series/${enc(username)}/${enc(password)}/$id.${item.containerExtension.ifBlank { "mp4" }}"
        }
    }
}
