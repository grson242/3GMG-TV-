package com.gmg.tv

data class XtreamAccount(
    val server: String,
    val username: String,
    val password: String,
    val expiryDate: String,
    val status: String
)

data class XtreamCategory(
    val id: String,
    val name: String
)

data class XtreamItem(
    val id: String,
    val name: String,
    val streamType: String,
    val categoryId: String = "",
    val icon: String = "",
    val containerExtension: String = ""
)
