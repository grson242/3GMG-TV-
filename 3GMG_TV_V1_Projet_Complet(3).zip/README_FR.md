# 3GMG TV — V1 Android TV

Prototype Android natif (Kotlin + vues Android) pour Android TV / Google TV.

## Fonctions de cette V1
- Écran de connexion : serveur, utilisateur, mot de passe.
- Connexion à l'API compatible Xtream Codes (`player_api.php`).
- Vérification de `user_info.auth` et affichage de la date d'expiration.
- Écrans de navigation : TV en direct, Films, Séries.
- Chargement des catégories et des éléments via les endpoints Xtream habituels.
- Lecteur vidéo Android natif pour ouvrir un flux sélectionné.
- Gestion des erreurs et bouton de déconnexion.

## Limites / sécurité
- C'est une base de développement, pas encore une application publiée ni auditée.
- N'intègre pas les identifiants partagés dans la conversation.
- Les identifiants sont conservés uniquement en mémoire pendant la session.
- La connexion HTTP est autorisée pour compatibilité avec certains serveurs. Pour une production, préférez HTTPS et faites vérifier la configuration par un développeur.
- Le comportement des API varie selon le panel/serveur. PacitoRs1 doit exposer une API compatible Xtream Codes pour que cette version fonctionne.
- Utilisez uniquement des flux et contenus pour lesquels vous disposez des droits nécessaires.

## Ouvrir et compiler
1. Installez Android Studio sur un ordinateur.
2. Décompressez le ZIP.
3. Dans Android Studio, ouvrez le dossier `3GMG_TV_V1`.
4. Laissez Gradle synchroniser le projet.
5. Choisissez `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
6. Le fichier debug est généralement créé dans `app/build/outputs/apk/debug/app-debug.apk`.

## Test
Pour vous connecter, entrez l'adresse du serveur, le nom d'utilisateur et le mot de passe d'un compte de test. Ne publiez jamais un lien M3U ou des identifiants réels.
